package com.divergentfact.geosnap

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private var imageCapture: ImageCapture? = null
    private var lastPhoto: File? = null
    private val fused by lazy { LocationServices.getFusedLocationProviderClient(this) }

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] != true &&
            result[Manifest.permission.ACCESS_COARSE_LOCATION] != true) {
            status.text = "Camera ready. Location permission is needed for GPS stamp/live sharing."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestPermissionsIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundColor(Color.rgb(246, 249, 247))
        }
        val title = TextView(this).apply {
            text = "GeoSnap"
            textSize = 28f
            setTextColor(Color.rgb(20, 125, 102))
            gravity = Gravity.CENTER_VERTICAL
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 54))
        val subtitle = TextView(this).apply {
            text = "Capture • Stamp • Share"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        }
        root.addView(subtitle)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = 12; bottomMargin = 12
        })
        status = TextView(this).apply {
            text = "Allow camera and location permissions to begin."
            textSize = 13f
            setTextColor(Color.DKGRAY)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })

        addButton(root, "📸  Take photo with location stamp") { capturePhoto() }
        addButton(root, "📤  Share latest photo") { sharePhoto() }
        addButton(root, "📍  Start live location sharing") { startLiveSharing() }
        addButton(root, "■  Stop live location sharing") { stopLiveSharing() }
        val note = TextView(this).apply {
            text = "Live sharing uses a private session link. Share it only with people you trust."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 8, 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = android.widget.Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 4 })
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.CAMERA)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) permissions.launch(needed.toTypedArray()) else startCamera()
    }

    private fun startCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                status.text = "Camera ready. GPS stamp is added when location is available."
            } catch (e: Exception) {
                status.text = "Camera could not start: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun capturePhoto() {
        val capture = imageCapture ?: run { toast("Camera is not ready"); return }
        if (!hasLocationPermission()) {
            toast("Grant location permission to add GPS stamp")
            requestPermissionsIfNeeded()
            return
        }
        status.text = "Capturing photo and getting location…"
        val token = CancellationTokenSource()
        try {
            fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, token.token)
                .addOnSuccessListener { loc ->
                    val locationLine = if (loc != null) {
                        try {
                            val geocoder = android.location.Geocoder(this, Locale.getDefault())
                            @Suppress("DEPRECATION")
                            val addresses = geocoder.getFromLocation(loc.latitude, loc.longitude, 1)
                            val address = addresses?.firstOrNull()?.getAddressLine(0)
                            if (!address.isNullOrBlank()) address else "%.5f, %.5f".format(Locale.US, loc.latitude, loc.longitude)
                        } catch (_: Exception) {
                            "%.5f, %.5f".format(Locale.US, loc.latitude, loc.longitude)
                        }
                    } else "Location unavailable"
                    val stamp = "$locationLine\n${SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault()).format(Date())}"
                    val file = File(cacheDir, "geosnap_${System.currentTimeMillis()}.jpg")
                    val options = ImageCapture.OutputFileOptions.Builder(file).build()
                    capture.takePicture(options, ContextCompat.getMainExecutor(this),
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                                try {
                                    val original = BitmapFactory.decodeFile(file.absolutePath)
                                    val stamped = addStamp(original, stamp)
                                    FileOutputStream(file).use { out ->
                                        stamped.compress(Bitmap.CompressFormat.JPEG, 92, out)
                                    }
                                    original.recycle()
                                    stamped.recycle()
                                    lastPhoto = file
                                    status.text = "Photo saved with location, date and time."
                                    toast("Photo captured")
                                } catch (e: Exception) {
                                    status.text = "Photo saved, but stamp failed: ${e.localizedMessage}"
                                }
                            }
                            override fun onError(exc: ImageCaptureException) {
                                status.text = "Capture failed: ${exc.localizedMessage}"
                            }
                        })
                }.addOnFailureListener { e ->
                    status.text = "Could not get GPS: ${e.localizedMessage}"
                }
        } catch (e: SecurityException) {
            status.text = "Location permission is required."
        }
    }

    private fun addStamp(source: Bitmap, stamp: String): Bitmap {
        val bitmap = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(bitmap)
        val padding = (bitmap.width * 0.025f).coerceAtLeast(18f)
        val textSize = (bitmap.width * 0.032f).coerceIn(18f, 42f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; this.textSize = textSize; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val lines = stamp.split("\n")
        val lineHeight = textSize * 1.35f
        val boxHeight = padding * 2 + lineHeight * lines.size
        val top = bitmap.height - boxHeight
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(190, 8, 24, 21) }
        canvas.drawRect(0f, top, bitmap.width.toFloat(), bitmap.height.toFloat(), bg)
        lines.forEachIndexed { index, line ->
            val fitted = ellipsize(line, paint, bitmap.width - padding * 2)
            canvas.drawText(fitted, padding, top + padding + textSize + index * lineHeight, paint)
        }
        return bitmap
    }

    private fun ellipsize(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var s = text
        while (s.isNotEmpty() && paint.measureText("$s…") > maxWidth) s = s.dropLast(1)
        return "$s…"
    }

    private fun sharePhoto() {
        val file = lastPhoto
        if (file == null || !file.exists()) { toast("Take a photo first"); return }
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) { toast("Could not prepare photo for sharing"); return }
        contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share GeoSnap photo"))
    }

    private fun startLiveSharing() {
        if (!hasLocationPermission()) { requestPermissionsIfNeeded(); toast("Grant location permission first"); return }
        val token = UUID.randomUUID().toString().replace("-", "").take(20)
        val intent = Intent(this, LiveLocationService::class.java).apply {
            action = LiveLocationService.ACTION_START
            putExtra(LiveLocationService.EXTRA_SESSION, token)
        }
        ContextCompat.startForegroundService(this, intent)
        val url = "https://YOUR_HOSTING_DOMAIN/?id=$token"
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "My GeoSnap live location (share only with trusted people): $url")
        }
        status.text = "Live sharing started. Choose a person to send the session link."
        startActivity(Intent.createChooser(share, "Share live location link"))
    }

    private fun stopLiveSharing() {
        stopService(Intent(this, LiveLocationService::class.java))
        status.text = "Live location sharing stopped."
        toast("Sharing stopped")
    }

    private fun hasLocationPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
