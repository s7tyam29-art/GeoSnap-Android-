# GeoSnap Android — source project

यह Android Studio के लिए source project है। इसमें CameraX photo capture, GPS permission, फोटो के नीचे location/date/time stamp, Android share sheet, और foreground service द्वारा consent-based live location sharing का implementation शामिल है।

**महत्वपूर्ण:** इस ZIP में बना हुआ APK नहीं है। APK बनाने के लिए Android Studio/Android SDK चाहिए। Firebase configuration और hosting setup के बिना live-sharing link काम नहीं करेगा।

## 1. Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35
- Firebase account (Realtime Database + Hosting)
- Android phone पर GPS और Internet

## 2. Android project खोलें
1. ZIP extract करें।
2. Android Studio → **Open** → `GeoSnapAndroid` folder चुनें।
3. Gradle sync पूरा होने दें।
4. Firebase Console में नया project बनाएं।
5. Android app add करें, package name ठीक यही रखें: `com.divergentfact.geosnap`
6. Firebase से `google-services.json` डाउनलोड करें और `app/` folder में रखें।
7. Firebase Console में Realtime Database बनाएं और database URL अपने Android app में set करें। `LiveLocationService.kt` में `FirebaseDatabase.getInstance()` को इस तरह बदलें:
   `FirebaseDatabase.getInstance("https://YOUR_DATABASE_URL").reference`
8. **Build → Build APK(s)** करें। Debug APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` पर मिलेगा।

## 3. Live location web viewer deploy करें
1. Firebase Console में Web App add करें और web config copy करें।
2. `firebase-hosting/public/index.html` में `firebaseConfig` के सभी placeholder values बदलें।
3. `firebase-hosting/database.rules.json` को production में सीधे deploy न करें। अभी की `.read: true` और `.write: true` rules सिर्फ quick prototype के लिए खुली हैं और कोई भी sessions पढ़/लिख सकता है। Production में Firebase Authentication, short-lived access, per-session authorization और rate limits लगाएं।
4. Firebase CLI install/login करें, `firebase init hosting` से अपने project को connect करें, फिर `firebase deploy --only hosting` चलाएं।
5. `MainActivity.kt` में `https://YOUR_HOSTING_DOMAIN/?id=$token` को अपने deployed Hosting URL से बदलें।
6. Android app में Realtime Database URL configure करें।

## 4. Photo stamp
- Capture पर location प्राप्त की जाती है।
- Address उपलब्ध हो तो address, नहीं तो latitude/longitude stamp होता है।
- नीचे dark translucent strip पर location और capture date/time लिखे जाते हैं।
- Share button Android Sharesheet खोलता है, जहाँ WhatsApp आदि चुना जा सकता है।

## 5. Live sharing behavior
- User खुद **Start live location sharing** दबाता है।
- Foreground service ongoing notification दिखाती है और लगभग हर 10 सेकंड में location update करती है।
- App से **Stop live location sharing** दबाने पर updates रुकती हैं और session `active=false` होता है।
- Sender को app से बाहर निकलने/notification बंद करने के बाद भी OS behavior और permissions पर निर्भरता रहेगी; test on target Android versions.
- Viewer page last known location दिखाती है और Google Maps खोल सकती है. यह background tracking stealthily नहीं करता.

## 6. Before real-world use — security checklist
- Firebase rules को public `.read/.write` से सुरक्षित करें; production के लिए यह अनिवार्य है.
- Prefer Firebase Authentication and a secure server-generated random session token with expiration.
- Expire/delete old session records automatically.
- Add an explicit share duration (e.g. 15 min / 1 hour), link revoke button, and user-visible active indicator.
- Verify Android 13+ notification permission and Android 14+ foreground-service behavior on real devices.
- Location accuracy/address depends on GPS, network, permissions and geocoder availability.
- For Play Store distribution, review current Google Play location permission and foreground-service policies.

## 7. Build limitations
This source is a functional starting implementation, not a tested/released APK. The project has not been built on a device in this environment. Android Studio may prompt for SDK or dependency updates.
